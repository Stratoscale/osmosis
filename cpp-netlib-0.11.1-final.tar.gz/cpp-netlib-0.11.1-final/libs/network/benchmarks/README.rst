Here we can collect some statistics about different areas of
performance in the :mod:`cpp-netlib`, including run-time and
compile-time.
